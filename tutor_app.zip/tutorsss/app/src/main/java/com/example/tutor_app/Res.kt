package com.example.tutor_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Res : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_res)
    }
}